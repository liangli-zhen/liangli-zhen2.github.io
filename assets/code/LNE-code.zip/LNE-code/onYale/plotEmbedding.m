function RF=plotEmbedding(Y,ColorV,titleStr,lambda)
% --- Plot the output embedding.
if size(Y,1)==2
Y=Y';
end
% figure
minY=min(min(Y));
maxY=max(max(Y));
% Y=Y.*4./(maxY-minY);
[m,n] = size(Y);
% % axis(2.5*[-1 1 -1 1]);
% axis square;
if n == 2
    scatter(Y(:,1),Y(:,2),20,ColorV,'filled');
    selcetIndex=[1:m];
    for ii=1:size(selcetIndex,2)
        iistr=sprintf('%d',selcetIndex(ii));
%         hold on;
%         text(Y(selcetIndex(ii),1),Y(selcetIndex(ii),2),iistr);
    end
%     hold on;
%     plot([Y(35,1),Y(37,1)],[Y(35,2),Y(37,2)]);
%     hold on;
%     plot([Y(24,1),Y(58,1)],[Y(24,2),Y(58,2)]);
     selcetIndex=[5,9,11,13,15,16,24,29,31,35,37,41,45,55,57,58,61];
 %    selcetIndex=[5,9,11,13,15,16,24,26,31,35,37,41,45,55,57,58,64,27,62];
%        selcetIndex=[5,11,13,31,35,37,41,45,55,57,64,59,22,17,23,28];%ISOMAP
%selcetIndex=[5,9,11,16,24,26,35,37,41,45,63,57,58,64,26,12,51];%lle
 %      selcetIndex=[5,11,13,35,37,41,45,27,8,57,64,59,22,17,23,28];%le
    for ii=1:size(selcetIndex,2)        
        pathName='.\Yale\';
        fileName=sprintf('%s%d_%d.jpg',pathName,1,selcetIndex(ii)+1);
        im = imread(fileName);
        im=im./4;
        hold on;
        image(im,'XData',[Y(selcetIndex(ii),1),Y(selcetIndex(ii),1)+0.1*(maxY-minY)],'YData',[Y(selcetIndex(ii),2)+0.12*(maxY-minY),Y(selcetIndex(ii),2)]);
        colormap(gray);
    end
    axis square;
elseif n == 3
   scatter3(Y(:,1),Y(:,2),Y(:,3),ColorV,12,'filled');
    axis tight;
elseif n == 1
    scatter(Y(:,1),ones(m,1),12,ColorV,'filled');
    axis tight;
else
    cla;
    axis([-1 1 -1 1]);
    text(-0.7,0,'Only plots 2D or 3D data');
    axis off;
end;
if (nargin>2)
   xlabel(titleStr,'Color',[0,0,0],'Fontsize',20);
end
if (nargin>3)   
   xlabel(strcat(titleStr,', \lambda=',sprintf('%0.3f',lambda)),'Color',[0,0,0],'Fontsize',20);
end
% axis(2.5*[-1 1 -1 1]);
% axis square;
set(gca,'Fontsize',20);
set(gcf,'Color',[1,1,1]);
axis on;
grid on;
