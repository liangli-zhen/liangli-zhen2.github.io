%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     Create Date:May 10th,2012
%     @ By Liangli Zhen
%     dataBase contains 'duck','cat','yale' 'orl' and 'handWriting' corresponding to
%     coil-20-proc-duck,coil-20-proc-cat,yale extend B,ORL face and USPS dataset
%     respectively.
%     objectsNo stands which object we choose
%     picNum stands how many pictures we want to get.
%     randFlag means we'll randomly get the object's index if picNum is less
%     than the whole number of this object.1 stand yes.
%     resizeFlag will used if we want to get compressed pictures to avoid out of
%     memery.1 stand yes.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function X=getSingleObect(dataBase,objectsNo,picNum,randFlag,resizeFlag,rpathName)
addpath('./Yale');
imData=[];
X=[];
pathName='';
selectIndex=[1:picNum];

if strcmp(dataBase,'duck')
    if (nargin > 5)
        pathName=rpathName;
    else
        pathName='E:\\matlab\\coil-20-proc\\';
    end
    if (nargin > 3)
        if randFlag==1
            selectIndex=randi(72,1,picNum);        
        end
    end
    for k=1:picNum
        fileName=sprintf('%sobj%d__%d.png', pathName, 1, selectIndex(k)-1);
        im = imread(fileName);
        if (nargin > 4)
            if resizeFlag==1
                im=imresize(im,[16,16]);
            end
        end
        imData=[imData im];
        y=reshape(im,size(im,1)*size(im,2),1);
        X=[X,y];
    end
elseif strcmp(dataBase,'cat')
    if (nargin > 5)
        pathName=rpathName;
    else
        pathName='E:\\matlab\\coil-20-proc\\';
    end
    if (nargin > 3)
        if randFlag==1
            selectIndex=randi(72,1,picNum);        
        end
    end
    for k=1:picNum
        fileName=sprintf('%sobj%d__%d.png', pathName, 4, selectIndex(k)-1);
        im = imread(fileName);
        if (nargin > 4)
            if resizeFlag==1
                im=imresize(im,[16,16]);
            end
        end      
        imData=[imData im];
        y=reshape(im,size(im,1)*size(im,2),1);
        X=[X,y];
    end
elseif strcmp(dataBase,'yale')
    if (nargin > 5)
        pathName=rpathName;
    else
        pathName='yale\\';
    end
    if (nargin > 3)
        if randFlag==1
            selectIndex=randi(64,1,picNum);        
        end
    end
    for i=1:picNum
        fileName=sprintf('%s%d_%d.jpg',pathName,objectsNo,selectIndex(i)+1);
        im = imread(fileName);
        if (nargin > 4)
            if resizeFlag==1
                 im=imresize(im,[32,32]);
%im=imresize(im,[16,16]);
            end
        end
%         imData=[imData im];
        y=reshape(im,size(im,1)*size(im,2),1);
        X=[X,y];
    end    
elseif strcmp(dataBase,'orl')
    if (nargin > 5)
        pathName=rpathName;
    else
        pathName='E:\\matlab\\ORL\\';
    end
    if (nargin > 3)
        if randFlag==1
            selectIndex=randi(64,1,picNum);        
        end
    end    
    for i=1:picNum
        fileName=sprintf('%ss%d\\%d.pgm', pathName, objectsNo, selectIndex(i));
        im = imread(fileName);
        if (nargin > 4)
            if resizeFlag==1
                im=imresize(im,[16,16]);
            end
        end
        imData=[imData im];
        y=reshape(im,size(im,1)*size(im,2),1);
        X=[X,y];
    end  
elseif strcmp(dataBase,'handWriting')
    if (nargin > 5)
        pathName=rpathName;
    else
        pathName='E:\\matlab\\USPS\\';
    end
    if (nargin > 3)
        if randFlag==1
            selectIndex=randi(1100,1,picNum);        
        end
    end
    fileName=sprintf('%sdigit%d.mat', pathName, objectsNo);
    yy=load(fileName);
    Xn=yy.digit;
    for i=1:picNum
    imData=[imData reshape(Xn(:,selectIndex(i)),16,[])];
    X=[X,Xn(:,selectIndex(i))];
    end    

end
X=double(X);
% imData=[imData(:,1:size(imData,2)/4);imData(:,size(imData,2)/4+1:size(imData,2)/2);imData(:,size(imData,2)/2+1:size(imData,2)*3/4);imData(:,size(imData,2)*3/4+1:size(imData,2))];
% figure
% imshow(imData);
% titleStr=sprintf('objectsNo%d - %d points with %d dimension',objectsNo,picNum,size(X,1));
% Title(titleStr);