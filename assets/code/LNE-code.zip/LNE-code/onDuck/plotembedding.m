function RF=plotembedding(Y,ColorV,titleStr,lambda)
% --- Plot the output embedding.
if size(Y,1)==2
Y=Y';
end
% figure
% minY=min(min(Y));
% maxY=max(max(Y));
% Y=Y.*4./(maxY-minY);
axis on;


[m,n] = size(Y);
% % axis(2.5*[-1 1 -1 1]);
% axis square;
if n == 2
    scatter(Y(:,1),Y(:,2),20,ColorV,'filled');
    selcetIndex=[1,10,19,28,37,46,55,64];
    for ii=1:size(selcetIndex,2)
        iistr=sprintf('%d',selcetIndex(ii));
        hold on;
        text(Y(selcetIndex(ii),1),Y(selcetIndex(ii),2),iistr,'FontSize',25);
    end
    hold on;
    plot([Y(selcetIndex(1),1),Y(selcetIndex(5),1)],[Y(selcetIndex(1),2),Y(selcetIndex(5),2)]);
    hold on;
    plot([Y(selcetIndex(3),1),Y(selcetIndex(7),1)],[Y(selcetIndex(3),2),Y(selcetIndex(7),2)]);
%     selcetIndex=[5,9,11,13,15,16,24,29,31,35,37,41,45,55,57,58,61];
    for ii=1:size(selcetIndex,2)        
        pathName='.\coil-20-proc\';
        fileName=sprintf('%sobj%d__%d.png', pathName, 1, selcetIndex(ii)-1);
        im = imread(fileName);
        im=im./4;
%         hold on;
%         image(im,'XData',[Y(selcetIndex(ii),1),Y(selcetIndex(ii),1)+0.3],'YData',[Y(selcetIndex(ii),2)+0.36,Y(selcetIndex(ii),2)]);
%         colormap(gray);
    end
    axis square;
elseif n == 3
   scatter3(Y(:,1),Y(:,2),Y(:,3),ColorV,12,'filled');
    axis tight;
elseif n == 1
    scatter(Y(:,1),ones(m,1),12,ColorV,'filled');
    axis tight;
else
    cla;
    axis([-1 1 -1 1]);
    text(-0.7,0,'Only plots 2D or 3D data','FontSize',18);
    axis off;
end;
if (nargin>2)
   xlabel(titleStr,'fontsize',20);
end
if (nargin>3)   
   xlabel(strcat(titleStr,', \lambda=',sprintf('%0.3f',lambda)),'fontsize',20);
end
% axis(2.5*[-1 1 -1 1]);
% axis square;
grid on;
set(gcf,'Color',[1,1,1]);
set(gca,'FontName','Times New Roman','FontSize',20);
