
%dataBase contains 'duck','cat','yale' 'orl' and 'handWriting'
%getSingleObect(dataBase,objectsNo,picNum,randFlag,resizeFlag,rpathName)
% X=getSingleObect('duck',1,72,10);
% X=getSingleObect('cat',1,72,10);
% X=getSingleObect('orl',1,10,10);
% X=getSingleObect('handWriting',1,100,10);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This file is the main process.
%Created on May 11th, 2012
%@ By Liangli Zhen.

% If you used the code or data set, please approximately cited the works [1]
% [1] Liangli ZHEN, Peng Xi, Dezhong Peng. 
%     Local Neighborhood Embedding for Unsupervised Nonlinear Dimension
%     Reduction.
%     Journal Of Software, 8 (2), Feb. 2013. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;close all;clc;

%  KArray=[8,10,15,20,30];
%  KArray=[5];
KArray=[5,8];
d=2;
ColorV=jet(72);
% lambda=[0,0.005,0.02,0.08,0.4];
lambda=[0.2,0.5];
%  lambda=[1e-7,1e-6,1e-5,1e-4,1e-3,1e-2,1e-1];
%lambda=[0.0005];
%lambda=[0.01:0.01:0.1];
%lambda=[0.001:0.001:0.1];
 manifoldType=[9];
%manifoldType=[4];
%  runMethodFlag=[2,3,4,5];
 runMethodFlag=[5];
%runMethodFlag=[4,5];
itimes=10;
%Get data
X=getSingleObect('duck',1,72,10);
X=X';

for imanifold=1:size(manifoldType,2)   
    
    for i=1:size(runMethodFlag,2)
                
        for kIndex=1:size(KArray,2)
            figure            
            K=KArray(kIndex);
%             subplot('Position',[left bottom width height]);
            
            if runMethodFlag(i)==1;
                %use pca
                [Y]=pca(X,d);            
                PlotEmbedding(Y,ColorV); 

            elseif runMethodFlag(i)==2;
                %use Laplacian Eigenmap
                [E,V] = leigs(X, 'nn', K, d+1);
                 Y = E(:,1:d);
                 titleStr=sprintf('LE  K=%d',K);
%                  subplot('Position',[0.1 0.55 0.4 0.4]);
                 PlotEmbedding(Y,ColorV,titleStr);


             elseif runMethodFlag(i)==3;
                 %use isomap
                options.dims =2;
                [YYY, R] = Isomap(X','k', K, options);
                [Y] = YYY.coords{1};
                titleStr=sprintf('ISOMAP  K=%d  ',K);
%                 subplot('Position',[0.5 0.55 0.4 0.4]);
                PlotEmbedding(Y,ColorV,titleStr);
                axis(4e4*[-1,1,-1,1]);

             elseif runMethodFlag(i)==4;
                %use LLE
                [W,Y]=lle(X',K,d);
                titleStr=sprintf('LLE  K=%d',K);
                
%                 subplot('Position',[0.1 0.05 0.4 0.4]);
                PlotEmbedding(Y,ColorV,titleStr);

             elseif runMethodFlag(i)==5;
                %use KNN-RSL
                for ilambda=1:size(lambda,2);
                    if ilambda==kIndex
                [W,Y]=lne(lambda(ilambda),X',K,d);
                titleStr=sprintf('LNE  K=%d',K);
                
%                 subplot('Position',[0.5 0.05 0.4 0.4]);
                plotembedding(Y,ColorV,titleStr,lambda(ilambda));  
                    end
                end            
            end
%         filename=sprintf('duck%d%d.eps',K,runMethodFlag(i));
%         filename2=sprintf('duck%d%d.fig',K,runMethodFlag(i));
%         saveas(gcf,filename);
%         saveas(gcf,filename2);
%         set(gcf,'visible','off');
%         delete(gcf);
        end    
    end
end

