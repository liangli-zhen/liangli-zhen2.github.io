function RF=plotEmbedding(Y,ColorV,titleStr,lambda)
% --- Plot the output embedding.
if size(Y,1)==2
   Y=Y';
end
[m,n] = size(Y);

% figure
if n == 2    
 scatter(Y(:,1),Y(:,2),20,ColorV,'filled');
elseif n == 3
   scatter3(Y(:,1),Y(:,2),Y(:,3),ColorV,12,'filled');
axis tight;
elseif n == 1
    scatter(Y(:,1),ones(m,1),12,ColorV,'filled');
axis tight;
else
    cla;
    axis([-1 1 -1 1]);
    text(-0.7,0,'Only plots 2D or 3D data');
    axis off;
end;
if (nargin>2)
   xlabel(titleStr,'fontsize',30);
end
if (nargin>3)   
   xlabel(strcat(titleStr,', \lambda=',sprintf('%0.3f',lambda)),'fontsize',30);
end


%     filename=sprintf('E:\\\\result\\\\points800\\\\%d',f);
%     saveas(gcf,filename,'bmp');
%     set(gcf,'visible','off');
%     delete(gcf);
set(gcf,'Color',[0.95,0.95,0.95]);
set(gca,'FontName','Times New Roman','FontSize',24);
grid on;
axis on;
% set(gca,'XColor',[0,0,0]);
% set(gca,'YColor',[0,0,0]);