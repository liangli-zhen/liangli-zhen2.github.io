%plot the manifold data source
function SF = DataSourcePlot(X,ColorV,titleStr)

[m,n] = size(X);
if n == 2    
    scatter(X(:,1),X(:,2),12,ColorV,'filled');    
    axis tight;
elseif n == 3
    scatter3(X(:,1),X(:,2),X(:,3),12,ColorV,'filled');
    axis tight;
elseif n == 1
    scatter(X(:,1),ones(m,1),12,'filled');   
    axis tight;
else
    cla;
    axis([-1 1 -1 1]);
    text(-0.7,0,'Only plots 2D or 3D data');
    axis off;
end;
if (nargin>2)
     Title(titleStr,'fontsize',30);
end
grid on;
axis on;
set(gcf,'Color',[0.95,0.95,0.95]);
set(gca,'XColor',[0,0,0]);
set(gca,'YColor',[0,0,0]);
set(gca,'ZColor',[0,0,0])
set(gca,'FontName','Times New Roman','FontSize',24) 