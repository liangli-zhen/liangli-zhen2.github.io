%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This file is the main process.
%Created on May 11th, 2012
%@ By Liangli Zhen. 

% If you used the code or data set, please approximately cited the works [1]
% [1] Liangli ZHEN, Peng Xi, Dezhong Peng. 
%     Local Neighborhood Embedding for Unsupervised Nonlinear Dimension
%     Reduction.
%     Journal Of Software, 8 (2), Feb. 2013. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;close all;clc;

KArray=[10,20,30];
d=2;
lambda=[0.05,0.2,0.5];

 manifoldType=[4,5,7];
%manifoldType=[5];
pointsNum=1000;
ColorV=jet(pointsNum);
%runMethodFlag=[2:5];
runMethodFlag=[5];

for imanifold=1:size(manifoldType,2)
    %Generate dataset
    [X,ColorV] = DataGen(manifoldType(imanifold),pointsNum,2);
     DataSourcePlot(X,ColorV);
    figure 
    for i=1:size(runMethodFlag,2) 
        for kIndex=1:size(KArray,2)
            K=KArray(kIndex);
%             subplot(4,3,(i-1)*3+kIndex);
            figure
            if runMethodFlag(i)==1;
                %use pca
                [Y]=pca(X,d);            
                PlotEmbedding(Y,ColorV); 

            elseif runMethodFlag(i)==2;
                %use Laplacian Eigenmap
                [E,V] = leigs(X, 'nn', K, d+1);
                 Y = E(:,1:d);
                 titleStr=sprintf('LE  K=%d',K);
                 PlotEmbedding(Y,ColorV,titleStr);

             elseif runMethodFlag(i)==3;
                 %use isomap
                options.dims =2;
                [YYY, R] = Isomap(X','k', K, options);
                [Y] = YYY.coords{1};
                titleStr=sprintf('ISOMAP  K=%d',K);
                PlotEmbedding(Y,ColorV,titleStr);

             elseif runMethodFlag(i)==4;
                %use LLE
                [W,Y]=lle(X',K,d);
                titleStr=sprintf('LLE  K=%d',K);
                PlotEmbedding(Y,ColorV,titleStr);

             elseif runMethodFlag(i)==5;
                %use lne
                for ilambda=1:size(lambda,2);                    
                    if ilambda==kIndex
                [W,Y]=lne(lambda(ilambda),X',K,d);
                titleStr=sprintf('LNE  K=%d',K);              
                plotEmbedding(Y,ColorV,titleStr,lambda(ilambda));  
                    end
                end            
            end
        axis on;
        grid on; 

        end    
    end

end

