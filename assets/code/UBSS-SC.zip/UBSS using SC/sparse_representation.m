
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% This function is used for solving the L1-Norm minimization problem.
% Mathmatic model: min lambda*||C||_1 + ||X - XC||_2  s.t.  diag(C) = 0;
% XD is the input data.
% W is the sparse representation coefficients
%-%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
function W = sparse_representation(X,lambda)
options.maxIteration = 2000;
options.isNonnegative = false;
STOPPING_OBJECTIVE_VALUE = 3;
options.stoppingCriterion = STOPPING_OBJECTIVE_VALUE;
options.lambda  = lambda;
options.tolerance  = 1E-12;
K = 1000;
N = size(X,2);
W = zeros(K,N);
% X2 = sum(X.^2,1);
% distance = repmat(X2,N,1)+repmat(X2',1,N)-2*X'*X;
% 
% [~,index] = sort(distance);
% clear distance;
% 
% neighborhood = index(2:(1+K),:);
for i = 1:N
    select_idx = randperm(N, K);
    [tmp_x, total_iter] = SolveHomotopy(X(:,select_idx), X(:,i), ...
        'maxIteration', options.maxIteration,...
        'isNonnegative', options.isNonnegative, ...
        'lambda', options.lambda, ...
        'tolerance', options.tolerance);
    
    W(:,i) = tmp_x;
    
end
end