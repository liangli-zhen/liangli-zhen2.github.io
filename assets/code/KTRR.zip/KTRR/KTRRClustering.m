% =========================================================================
% Written by Liangli Zhen (llzhen@outlook.com)
% Machine Intelligence Lab, School of Computer Science, Sichuan University;
% CERCIA, School of Computer Science, University of Birmingham.
% Dec., 2016.

% Reference:
% L. Zhen, D. Peng, X. Yao, "Kernel Truncated Regression Representation for
% Robust Subspace Clustering", 2016.
% =========================================================================
% Input:
% dat is the input data matrix, each column denotes a data point.
% labels the labels of the corresponding data points in the input dat.
% par includes other parameters, such as the used kernel, labmda, threshold
% eta
% Output:
% accuracy, nmi, Fscore, Precision, ARI, Recall are clustering performance accuracy indices.
% time, Time_BuildGraph are time cost in the whole clustering process and
% similarity graph construction, respectively.

function [accuracy, nmi, Fscore, Precision, ARI, Recall, time, Time_BuildGraph] = KTRRClustering(dat, labels, par)
accuracy = zeros(length(par.lambda),length(par.adjKnn));
nmi = zeros(length(par.lambda),length(par.adjKnn));
Fscore= zeros(length(par.lambda),length(par.adjKnn));
Precision = zeros(length(par.lambda),length(par.adjKnn));
ARI = zeros(length(par.lambda),length(par.adjKnn));
Recall= zeros(length(par.lambda),length(par.adjKnn));

pos = 0;

for i = 1:length(par.lambda)
    tic;
    opts.kernel   = par.kernel; 
    opts.mode     = 'Test';
    opts.name     =par.name;
    [ker, ~]= return_kernel(dat', dat', opts.kernel);
    [coef] = ktrr_core_fun(ker, par.lambda(i));
    Time_BuildGraph(i) = toc;
    
    for j = 1:length(par.adjKnn)
        % --- CKSym: NxN symmetric adjacency matrix
        
        tic;
        CKSym = BuildAdjacency(coef,par.adjKnn(j));
        predict_label = SC(CKSym,length(unique(labels)));
        time(i,j)=Time_BuildGraph(i)+toc;
        predict_label = reshape(predict_label,1,[]);
        [t_accuracy, t_nmi, t_ARI, t_Precision, t_Recall, t_Fscore]= CalMetricOfCluster(predict_label,labels);
        Fscore(i,j) = t_Fscore;
        Precision(i,j) = t_Precision;
        ARI(i,j) = t_ARI;
        Recall(i,j) = t_Recall;
        accuracy(i,j) = t_accuracy;
        nmi(i,j) = t_nmi;
        pos = pos + 1;
        fprintf([' | the ' num2str(pos) 'th result | lambda = ' num2str(par.lambda(i)) ' | adjKnn = ' num2str(par.adjKnn(j)) '\n']);
        fprintf([' + The accuracy                      scores are: ' num2str(t_accuracy) '\n']);
        fprintf([' + The normalized mutual information scores are: ' num2str(t_nmi) '\n']);
        fprintf(' + The time cost for building graph is about %f seconds \n', Time_BuildGraph(i));
        fprintf(' + The total time cost is about              %f seconds \n\n', time(i));
    end;
end;
