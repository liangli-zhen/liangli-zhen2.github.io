% =========================================================================
% Written by Liangli Zhen (llzhen@outlook.com)
% Machine Intelligence Lab, School of Computer Science, Sichuan University;
% CERCIA, School of Computer Science, University of Birmingham.
% Dec., 2016.
% =========================================================================
% Description: KTRR- for image clustering.
% Each column vector corresponds to a data point
% Monte Carlo experiments run for 10 times.


close all; clear all; clc;

%% --------------------------------------------------------------------------
addpath ('./usages/');
addpath ('./data/');
data_sets = {'COIL20'};

for i = 1:length(data_sets)
    CurData = char(data_sets(i));
    load(CurData);
    dat = double(fea');
    labels = gnd;
    
    % -----parameters configuration
    par.nRep = 10;
    par.kernel = 'rbf';
    par.nClass = length(unique(labels));
    par.name = CurData;
    
    switch CurData
        case 'YaleB_32x32'
            par.lambda             =  [0.5];
            par.adjKnn             =   [6];
        case 'COIL20'
            par.lambda             =  [10];
            par.adjKnn             =   [4];
        case 'USPS'
            par.lambda             =  [5];
            par.adjKnn             =   [3];
        case 'mnist10kTrain'
            par.lambda             =  [100];
            par.adjKnn             =   [5];
        otherwise
            error(['The dataset ',CurData,'is not existed.\n']);
    end
    
    
    % --- get the clustering result based on KTRR-graph
    performance = [];
    for j = 1:par.nRep
        if strcmp(CurData,'USPS')
            filename = ['USPS_2000_Rep_' num2str(j)];
            load(filename);
            dat = double(fea');
            labels = gnd;
            par.nClass = length(unique(labels));
            par.nDim = size(dat,1);
            par.name = filename;
        end
        if strcmp(CurData,'mnist10kTrain')
            filename = ['mnist10kTrain_2000_Rep_' num2str(j)];
            load(filename);
            dat = double(fea');
            labels = gnd;
            par.nClass = length(unique(labels));
            par.nDim = size(dat,1);
            par.name = filename;
        end
        [accuracy, nmi, Fscore, Precision, ARI, Recall, time, Time_BuildGraph] = KTRRClustering(dat, labels, par);
        
        performance = [performance; max(max(accuracy)) max(max(nmi)) max(max(Fscore)) max(max(Precision)) max(max(ARI)) max(max(Recall))];
        fprintf(['Mento carlo runs ' num2str(j) ' times\n']);
    end
    clear dat labels fea gnd;
    save (['KTRR_SC_' CurData '_nClass' num2str(par.nClass) '_nRep' num2str(par.nRep) '.mat']);
    
    performance = performance.*100;
    for k = 1:size(performance,2)
        std = sum((performance(:,k) - mean(performance(:,k))).^2).^0.5;
        fprintf(['\n' num2str(mean(performance(:,k)),'%.2f') '+' num2str(std,'%.2f')]);
    end
    fprintf('\n');
end