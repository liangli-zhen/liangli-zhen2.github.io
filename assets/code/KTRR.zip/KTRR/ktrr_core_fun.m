
% =========================================================================
% Written by Liangli Zhen (llzhen@outlook.com)
% Machine Intelligence Lab, School of Computer Science, Sichuan University;
% CERCIA, School of Computer Science, University of Birmingham.
% Dec., 2016.
% Reference:
% L. Zhen, D. Peng, X. Yao, "Kernel Truncated Regression Representation for
% Robust Subspace Clustering", 2016.
% =========================================================================

function [W] = ktrr_core_fun(ker, lambda)
   P = pinv( ker + lambda*eye(size(ker))); 
   W = zeros(size(ker));
   for i = 1:size(W,2)
       Q = P*ker(:,i);
       stdOrthbasis = zeros(size(ker,2),1);
       stdOrthbasis(i,1) = 1;
       W(:,i) = P*(ker(:,i) - Q(i,1).*stdOrthbasis./P(i,i));
   end
   W = W - eye(size(W)).*W;
   W = W./( repmat(sqrt(sum(W.*W)), [size(W, 1),1]) );
end 


