function [kernel, kernel_paramter] = return_kernel(features1, features2, kernel_type, kernel_paramter)

%   Note that normualization is involved in this code by default.

%   Example usage:
%       [kernel, kernel_paramter] = return_kernel(rand(10,3), rand(5,3), 'rbf')
if nargin < 4
    flag = 0;
else
    flag = 1;
end

if ismember(kernel_type, {'rbf', 'lap', 'isd', 'id'})
    tmp = sqrt(sum(features1.^2, 2));
    %     tmp = sum(features1, 2);
    non0_index = find(tmp ~= 0);
    features1(non0_index, :) = features1(non0_index, :) ./ repmat(tmp(non0_index,:), 1, size(features1, 2));
    
    tmp = sqrt(sum(features2.^2, 2));
    %     tmp = sum(features2, 2);
    non0_index = find(tmp ~= 0);
    features2(non0_index, :) = features2(non0_index, :) ./ repmat(tmp(non0_index,:), 1, size(features2, 2));
end

switch kernel_type
    case 'rbf'
        square_distance_matrix = L2_SquareDistance(features1', features2');
        sigma_sqr = mean(square_distance_matrix(:));
        if flag == 0
            kernel_paramter = 1 / sigma_sqr;
        end
        kernel = exp(- kernel_paramter * square_distance_matrix);
        
    case 'lap'
        square_distance_matrix = L2_SquareDistance(features1', features2');
        sigma_sqr = mean(square_distance_matrix(:));
        if flag == 0
            kernel_paramter = 1 / sigma_sqr;
        end
        kernel = exp(- sqrt(kernel_paramter * square_distance_matrix));
        
    case 'isd'
        square_distance_matrix = L2_SquareDistance(features1', features2');
        sigma_sqr = mean(square_distance_matrix(:));
        if flag == 0
            kernel_paramter = 1 / sigma_sqr;
        end
        kernel = 1./(kernel_paramter * square_distance_matrix + 1);
        
    case 'id'
        square_distance_matrix = L2_SquareDistance(features1', features2');
        sigma_sqr = mean(square_distance_matrix(:));
        if flag == 0
            kernel_paramter = 1 / sigma_sqr;
        end
        kernel = 1./(sqrt(kernel_paramter * square_distance_matrix) + 1);
    case {'hik','hik2','chisq'}
        %================================   add path ( for updating alphas)
        Current_Path  = mfilename('fullpath');
        places        =  strfind( Current_Path, '\') ;
        Current_Path  = Current_Path( 1 : places(end) );
        addpath([Current_Path,'pwmetric_from_ChenLin\pwmetric\']);
        %================================================================
        switch kernel_type
            
            case 'hik'
                kernel = slmetric_pw(features1', features2', 'intersect');
                kernel_paramter = 0;
            case 'hik2'
                distance_matrix = slmetric_pw(features1', features2', 'intersectdis');
                sigma_sqr = mean(distance_matrix(:));
                if flag == 0
                    kernel_paramter = 1 / sigma_sqr;
                end
                kernel = exp(- kernel_paramter * distance_matrix);
                
            case 'chisq'
                distance_matrix = slmetric_pw(features1', features2', 'chisq');
                sigma_sqr = mean(distance_matrix(:));
                if flag == 0
                    kernel_paramter = 1 / sigma_sqr;
                end
                kernel = exp(- kernel_paramter * distance_matrix);
        end
    otherwise
        error('this kernel type is NOT supported')
end

end

function d = L2_SquareDistance(a,b,df)
% L2_DISTANCE - computes square Euclidean distance matrix
%
% E = L2_distance(A,B)
%
%    A - (DxM) matrix
%    B - (DxN) matrix
%    df = 1, force diagonals to be zero; 0 (default), do not force
%
% Returns:
%    E - (MxN) Euclidean distances between vectors in A and B
%
%
% Description :
%    This fully vectorized (VERY FAST!) m-file computes the
%    Euclidean distance between two vectors by:
%
%                 ||A-B|| = sqrt ( ||A||^2 + ||B||^2 - 2*A.B )
%
% Example :
%    A = rand(400,100); B = rand(400,200);
%    d = distance(A,B);

% Author   : Roland Bunschoten
%            University of Amsterdam
%            Intelligent Autonomous Systems (IAS) group
%            Kruislaan 403  1098 SJ Amsterdam
%            tel.(+31)20-5257524
%            bunschot@wins.uva.nl
% Last Rev : Wed Oct 20 08:58:08 MET DST 1999
% Tested   : PC Matlab v5.2 and Solaris Matlab v5.3

% Copyright notice: You are free to modify, extend and distribute
%    this code granted that the author of the original code is
%    mentioned as the original author of the code.

% Fixed by JBT (3/18/00) to work for 1-dimensional vectors
% and to warn for imaginary numbers.  Also ensures that
% output is all real, and allows the option of forcing diagonals to
% be zero.

if (nargin < 2)
    error('Not enough input arguments');
end

if (nargin < 3)
    df = 0;    % by default, do not force 0 on the diagonal
end

if (size(a,1) ~= size(b,1))
    error('A and B should be of same dimensionality');
end

if ~(isreal(a)*isreal(b))
    disp('Warning: running distance.m with imaginary numbers.  Results may be off.');
end

if (size(a,1) == 1)
    a = [a; zeros(1,size(a,2))];
    b = [b; zeros(1,size(b,2))];
end

aa=sum(a.*a); bb=sum(b.*b); ab=a'*b;
d = repmat(aa',[1 size(bb,2)]) + repmat(bb,[size(aa,2) 1]) - 2*ab;

% make sure result is all real
d = real(d);

% force 0 on the diagonal?
if (df==1)
    d = d.*(1-eye(size(d)));
end
end