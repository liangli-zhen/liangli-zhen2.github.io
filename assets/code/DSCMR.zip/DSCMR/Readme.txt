This package contains the source code based on Pytorch framework for the paper:

Deep Supervised Cross-modal Retrieval

Liangli Zhen, Peng Hu, Xu Wang, Dezhong Peng

IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 2019


The feature vectors of the Pascal Sentence dataset is available at https://github.com/penghu-cs/DSCMR/tree/master/data. The feature vectors of the Wikipedia, NUS-WIDE10k and XMediaNet datasets cannot be provided by us because of the copyright of these datasets.

These features are extracted by using the VGG feature extractor in the Pytorch models (pre-trained on the ImageNet dataset) and the sentence CNN feature extractor at https://github.com/yoonkim/CNN_sentence.




Please feel free to contact me if you have any questions about the paper and/or the source code.

Liangli Zhen (Email: llzhen@outlook.com)