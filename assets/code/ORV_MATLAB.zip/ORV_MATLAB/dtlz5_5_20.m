% =========================================================================
% Written by Liangli Zhen (llzhen@outlook.com)
% CERCAI, School of Computer Science, Unviersity of Birmingham
% MILab, School of Computer Science, Sichuan Unviersity
% September, 2016.
% =========================================================================
% Description:
% L. Zhen, M. Li, D. Peng, X. Yao.
% Visualizing Many-Objective Solution Sets through Objective
% Decomposition
% The experiment on DTLZ(I,M) problem, where I = 4, M = 20.

clear all; close all; clc

% Load the solutions of one specific many-objective evolutionary algorithms
Global.I = 4; Global.M = 20; population_size = 100;
X_OBJ = importdata('DTLZ5(4,20)Obj.txt');

a = ['DTLZ' num2str(i) 'Obj.txt'];

M = Global.M;

% Begin the timing process of objective decomposition process.
tic

% Parameter setting
m = 4; % The number of remained objectives.
reconstruction_threshold = 0.5;
correlation_threshold = 0.01;
lambda = 0.001;


X = X_OBJ;
% The decomposed objectives flags used to indicate which objectives are decomposed.
decomposed_obj_set = [];

corX = corrcoef(X); % computer the correlation matrix
corX(logical(eye(size(corX)))) = -1;
Residual_for_solutions = zeros(size(X, 1), 1);
ColorV=jet(size(X,1));
for dim_i = M:-1:m+1
    % The remaind_obj_set indicates which objectives are still existed.
    remaind_obj_set = setdiff(1:M, decomposed_obj_set);
    Residual = zeros(size(X,1), size(remaind_obj_set, 2));
    reco_idx = cell(1,size(remaind_obj_set, 2));
    reco_cof = cell(1,size(remaind_obj_set, 2));
    for i = 1:size(remaind_obj_set, 2)
        
        reco_idx{i} = setdiff(find(corX(:, remaind_obj_set(i)) > correlation_threshold), decomposed_obj_set);
        Di = X(:, reco_idx{i});
        
        cvx_begin
        variable cw(size(Di,2))
        minimize(lambda*norm(cw,1) + norm(Di*cw-X(:,remaind_obj_set(i))))
        subject to
        cw >= 0;
        cvx_quiet(true);
        cvx_end
        
        reco_cof{i}=cw;
%         if ~isempty(reco_cof{i})
%             fprintf(['Decomposition of objective ' num2str(remaind_obj_set(i)) ' with coefficients: ' num2str(reco_cof{i}') '\n']);
%             fprintf(['On the dimensions of  ' num2str(reco_idx{i}') '\n']);
%         end
        Residual(:, i) = X(:, remaind_obj_set(i)) - X(:, reco_idx{i})* reco_cof{i};
    end
    [~,u] =  min(sum(Residual.^2, 1));
    u = u(1,1);
    X(:, reco_idx{u}) = X(:, reco_idx{u}).*(repmat(ones(1,length(reco_cof{u})) + reco_cof{u}',size(X,1),1));
    Residual_for_solutions = Residual_for_solutions + Residual(:, u);
    
    
    fprintf(['\nFinal Decomposition of objective ' num2str(remaind_obj_set(1, u)) ' with coefficients: ' num2str(reco_cof{u}') '\n']);
    fprintf('On the objectives of');
    for printi = 1:length(reco_idx{u})
        fprintf([' ' num2str(reco_idx{u}(printi))]);
    end
    fprintf('\n\n');
    
    decomposed_obj_set = [decomposed_obj_set , remaind_obj_set(1, u)];
    remaind_obj_set(u) = [];
   
end

Y = X(:, setdiff(1:M, decomposed_obj_set));
fprintf(['The final objectives are ' num2str(setdiff(1:M, decomposed_obj_set)) '\n']);
time_cost = toc



threshold_num = 0;
abnorm_sets = [];
for i = 1:size(Residual_for_solutions,1)
    if Residual_for_solutions(i, 1) > reconstruction_threshold
        fprintf(['sigma_idx =' num2str(i) '    sigma_value =' num2str(Residual_for_solutions(i, 1)) '\n']);
        threshold_num = threshold_num + 1;
        abnorm_sets = [abnorm_sets i];
    end
end
fprintf(['Number of the reconstruction errors which are larger than ' num2str(reconstruction_threshold)  '  = '  num2str(threshold_num) '\n\n']);
if m ==3
    figure; scatter3(Y(:,1),Y(:,2),Y(:,3),20,ColorV,'fill');
    ylim([0, 1.2]);
    xlabel('$f_6$','interpreter','latex');
    ylabel('$f_9$','interpreter','latex');
    zlabel('$f_{10}$','interpreter','latex');    
    set(gca,'fontsize',16, 'GridLineStyle', '-.','LineWidth', 1.5);
    grid on;
    
    figure; scatter3(Y(:,1),Y(:,2),Y(:,3),10,'k','fill');
    ylim([0, 1.2]);
    xlabel('$f_6$','interpreter','latex');
    ylabel('$f_9$','interpreter','latex');
    zlabel('$f_{10}$','interpreter','latex');    
    set(gca,'fontsize',16, 'GridLineStyle', '-.','LineWidth', 1.5);
    grid on;
    for i = 1:length(abnorm_sets)
        hold on
        scatter3(Y(abnorm_sets(i), 1), Y(abnorm_sets(i), 2), Y(abnorm_sets(i), 3), ...
            'MarkerEdgeColor','k',...
            'MarkerFaceColor',[0 .75 .75]);
    end
    Domaint_num = 0;
    Z = Y;
    for i = 1:size(Z,1)
        for j = i+1:size(Z,1)
            if (Z(i,1)<Z(j,1))&&(Z(i,2)<Z(j,2))&&(Z(i,3)<Z(j,3))
                Domaint_num = Domaint_num + 1;
                
            end
        end
    end
    fprintf(['Number of dominant solution pairs = ' num2str(Domaint_num) '\n']);
end
figure; plot(Y','LineWidth',1.5);
xlabel('Objective number');
ylabel('Objective value');
set(gca,'XTick',1:4);
set(gca,'XTickLabel',{'17' '18' '19' '20'});
set(gca,'fontsize',14, 'GridLineStyle', '-.','LineWidth', 2);

figure; plot(X_OBJ','LineWidth',1.5);
xlabel('Objective number');
ylabel('Objective value');
set(gca,'XTick',1:20);
xlim([1,20]);
set(gca,'fontsize',14, 'GridLineStyle', '-.','LineWidth', 2);
