% =========================================================================
% Written by Liangli Zhen (llzhen@outlook.com)
% CERCAI, School of Computer Science, Unviersity of Birmingham
% MILab, School of Computer Science, Sichuan Unviersity
% September, 2018.
% =========================================================================
% Description:
% L. Zhen, M. Li, D. Peng, X. Yao.
% Objective Reduction for Visualising Many-Objective Solution Sets
% The experiment on Rectangle problem.
% close all;
close all; clear all;  clc
% 
X_D = importdata('2varML-DMP(MOEADPBI).txt');
X_OBJ = importdata('5objML-DMP(MOEADPBI).txt');

addpath('./cvx')


ColorV=jet(size(X_OBJ,1));
M = size(X_OBJ,2);

% Begin the timing process of objective decomposition process.
tic

% Parameter setting
m = 3; % The number of remained objectives.
reconstruction_threshold = 0.5;
correlation_threshold = 0.01;
lambda = 0.001;

X = X_OBJ;
% The decomposed objectives flags used to indicate which objectives are decomposed.
decomposed_obj_set = [];

corX = corrcoef(X); % computer the correlation matrix
corX(logical(eye(size(corX)))) = -1;

Residual_for_solutions = zeros(size(X, 1), 1);

for dim_i = M:-1:m+1
    % The remaind_obj_set indicates which objectives are still existed.
    remaind_obj_set = setdiff(1:M, decomposed_obj_set);
    Residual = zeros(size(X,1), size(remaind_obj_set, 2));
    reco_idx = cell(1,size(remaind_obj_set, 2));
    reco_cof = cell(1,size(remaind_obj_set, 2));
    for i = 1:size(remaind_obj_set, 2)
        
        reco_idx{i} = setdiff(find(corX(:, remaind_obj_set(i)) > correlation_threshold), decomposed_obj_set);
        Di = X(:, reco_idx{i});
        
        cvx_begin
        variable cw(size(Di,2))
        minimize(lambda*norm(cw,1) + norm(Di*cw-X(:,remaind_obj_set(i))))
        subject to
        cw >= 0;
        cvx_quiet(true);
        cvx_end
        
        reco_cof{i}=cw;
        %         if ~isempty(reco_cof{i})
        %             fprintf(['Decomposition of objective ' num2str(remaind_obj_set(i)) ' with coefficients: ' num2str(reco_cof{i}') '\n']);
        %             fprintf(['On the dimensions of  ' num2str(reco_idx{i}') '\n']);
        %         end
        Residual(:, i) = X(:, remaind_obj_set(i)) - X(:, reco_idx{i})* reco_cof{i};
    end
    [v,u] =  min(sqrt(sum(Residual.^2, 1))./sqrt(sum(X(:, remaind_obj_set).^2, 1)));
    u = u(1,1);
    X(:, reco_idx{u}) = X(:, reco_idx{u}).*(repmat(ones(1,length(reco_cof{u})) + reco_cof{u}',size(X,1),1));
    Residual_for_solutions = Residual_for_solutions + Residual(:, u);
    
    
    fprintf(['\nFinal Decomposition of objective ' num2str(remaind_obj_set(1, u)) ' with coefficients: ' num2str(reco_cof{u}') '\n']);
    fprintf('on the objectives of');
    for printi = 1:length(reco_idx{u})
        fprintf([' ' num2str(reco_idx{u}(printi))]);
    end
    fprintf([' with residual of ' num2str(v) '\n\n']);
    
    decomposed_obj_set = [decomposed_obj_set , remaind_obj_set(1, u)];
    remaind_obj_set(u) = [];
    
end

Y = X(:, setdiff(1:M, decomposed_obj_set));
fprintf(['The final objectives are ' num2str(setdiff(1:M, decomposed_obj_set)) '\n']);
time_cost = toc




if m ==3
    ColorV=jet(size(X,1));
    %     figure; scatter3(Y(:,1),Y(:,2),Y(:,3),30,ColorV,'fill');
    figure; scatter3(Y(:,1),Y(:,2),Y(:,3),30,'MarkerEdgeColor','k',...
        'MarkerFaceColor',[.7 .7 .7],'LineWidth', 1.5);
    xlabel('$f_2$','interpreter','latex');
    ylabel('$f_4$','interpreter','latex');
    zlabel('$f_{5}$','interpreter','latex');
    set(gca,'fontsize',16, 'GridLineStyle', '-.','LineWidth', 1.5);
%     hold on; plot3([0;0],[0;0],[0;3],'k'); %A
%     hold on; plot3([0;0],[0;3],[0;0],'k'); %B
%     hold on; plot3([0;4],[0;0],[0;0],'k'); %C
    hold on; plot3([4;4],[0;0],[0;3],'k'); %A
    hold on; plot3([4;4],[0;3],[0;0],'k'); %B
    hold on; plot3([0;4],[0;0],[0;0],'k'); %C
    grid off;
    
    Domaint_num = 0;
    Z = Y;
    CombineNum = 0;
    for i = 1:size(Z,1)
        for j = i+1:size(Z,1)
            if (Z(i,1)<Z(j,1))&&(Z(i,2)<Z(j,2))&&(Z(i,3)<Z(j,3))
                Domaint_num = Domaint_num + 1;
            end
            CombineNum = CombineNum+1;
        end
    end
    fprintf(['Number of dominant solution pairs = ' num2str(Domaint_num) ' with ratio equals ' num2str(Domaint_num/CombineNum) ' in our proposed method.\n']);
end


[V,D] = eig(X_OBJ'*X_OBJ);
PX = X_OBJ*V(:,3:5);

if size(PX, 2) ==3
    figure; scatter3(PX(:,1),PX(:,2),PX(:,3),30,'MarkerEdgeColor','k',...
        'MarkerFaceColor',[.7 .7 .7],'LineWidth', 1.5);
    xlabel('$y_1$','interpreter','latex');
    ylabel('$y_2$','interpreter','latex');
    zlabel('$y_{3}$','interpreter','latex');
    set(gca,'fontsize',16, 'GridLineStyle', '-.','LineWidth', 1.5);
    
    grid off
    hold on; plot3([2;2],[-2;-2],[1.7;1.9],'k'); %A
    hold on; plot3([2;2],[-2;2],[1.7;1.7],'k'); %B
    hold on; plot3([-2;2],[-2;-2],[1.7;1.7],'k'); %C
    Domaint_num = 0;
    Z = PX;
    CombineNum = 0;
    for i = 1:size(Z,1)
        for j = i+1:size(Z,1)
            if (Z(i,1)<Z(j,1))&&(Z(i,2)<Z(j,2))&&(Z(i,3)<Z(j,3))
                Domaint_num = Domaint_num + 1;
            end
            CombineNum = CombineNum+1;
        end
    end
    fprintf(['Number of dominant solution pairs = ' num2str(Domaint_num) ' with ratio equals ' num2str(Domaint_num/CombineNum) ' in PCA.\n']);
end



% Calculate the AD of our proposed method
[AD1, AD2] = distdiff(X_OBJ', Y');

% Calculate the AD of PCA
[PAD1, PAD2] = distdiff(X_OBJ', PX');



figure; scatter(X_D(:,1),X_D(:,2),30,ColorV,'fill');
figure; scatter(X_D(:,1),X_D(:,2),30,'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.7 .7 .7],'LineWidth', 1.5);
set(gca,'fontsize',16, 'GridLineStyle', '-.','LineWidth', 1.5);
box on;