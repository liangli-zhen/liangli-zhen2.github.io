% Calculate the AD_1 and AD_2

function [AD1, AD2] = distdiff(X_OBJ, Y)
N = size(X_OBJ,2);
distanceX = zeros(N,N);
for i = 1:N
    distanceX(i,:) = sum(abs(repmat(X_OBJ(:, i), 1, N)  -  X_OBJ),1);
end

distanceY = zeros(N,N);
for i = 1:N
    distanceY(i,:) = sum(abs(repmat(Y(:, i), 1, N)  -  Y),1);
end

AD1 = sum(sum(abs(distanceX - distanceY),1))/(N*N);


distanceX = zeros(N,N);
for i = 1:N
    distanceX(i,:) = sqrt(sum((repmat(X_OBJ(:, i), 1, N)  -  X_OBJ).^2,1));
end

distanceY = zeros(N,N);
for i = 1:N
    distanceY(i,:) = sqrt(sum((repmat(Y(:, i), 1, N)  -  Y).^2,1));
end

AD2 = sum(sum(abs(distanceX - distanceY),1))/(N*N);
end